#ifndef HTTPSERVER_H
#define HTTPSERVER_H

#include <QTcpServer>
#include <QTcpSocket>
#include <QThread>

class HttpServer : public QTcpServer {
    Q_OBJECT

public:
    explicit HttpServer(QObject *parent = nullptr);

protected:
    void incomingConnection(qintptr socketDescriptor) override;
};

class ConnectionHandler : public QThread {
    Q_OBJECT

public:
    explicit ConnectionHandler(qintptr socketDescriptor, QObject *parent = nullptr);
    void run() override;

private:
    qintptr m_socketDescriptor;
};

#endif // HTTPSERVER_H
