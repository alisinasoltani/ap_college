#include "HttpServer.h"
#include <QDebug>

HttpServer::HttpServer(QObject *parent) : QTcpServer(parent) {}

void HttpServer::incomingConnection(qintptr socketDescriptor) {
    // Create a new thread to handle the connection
    ConnectionHandler *handler = new ConnectionHandler(socketDescriptor, this);
    connect(handler, &QThread::finished, handler, &QObject::deleteLater);
    handler->start();
}

// ConnectionHandler Implementation
ConnectionHandler::ConnectionHandler(qintptr socketDescriptor, QObject *parent)
    : QThread(parent), m_socketDescriptor(socketDescriptor) {
}

void ConnectionHandler::run() {
    QTcpSocket socket;
    if (!socket.setSocketDescriptor(m_socketDescriptor)) {
        qCritical() << "Failed to set socket descriptor";
        return;
    }

    // Monitor socket state changes (optional, for debugging)
    connect(&socket, &QTcpSocket::stateChanged, [](QAbstractSocket::SocketState state) {
        qDebug() << "Socket state changed to:" << state;
    });

    // Read the incoming request
    if (socket.waitForReadyRead(10000)) { // Wait for data with a timeout
        QByteArray request = socket.readAll();
        qDebug() << "Request received:\n" << request;

        // Prepare a simple HTTP response
        QByteArray response =
            "HTTP/1.1 200 OK\r\n"
            "Content-Type: text/plain\r\n"
            "Connection: close\r\n"
            "\r\n"
            "Hello, Multithreaded World!";

        // Write the response
        if (socket.state() == QAbstractSocket::ConnectedState) {
            qint64 bytesWritten = socket.write(response);
            if (bytesWritten == -1) {
                qWarning() << "Failed to write response to socket.";
            } else {
                qDebug() << "Bytes written:" << bytesWritten;
                socket.flush();
            }
        } else {
            qWarning() << "Socket disconnected before response could be sent.";
        }
    } else {
        qWarning() << "No data received within the timeout.";
    }

    // Gracefully close the connection
    if (socket.state() == QAbstractSocket::ConnectedState) {
        socket.disconnectFromHost();
        if (socket.state() != QAbstractSocket::UnconnectedState) {
            if (!socket.waitForDisconnected(10000)) {
                qWarning() << "Socket did not disconnect cleanly.";
            }
        }
    } else {
        qDebug() << "Socket already disconnected.";
    }
}

