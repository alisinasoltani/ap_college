#include <iostream>
#include "Gun.h"

using namespace std;

int main() {
    Gun a("sina", 100, 2.2, true), b("ali", 100, 3.3, false), c;
    std::cin >> c;
    std::cout << c;
    std::cout << a;
    a++;
    std::cout << a;
    ++a;
    std::cout << a;
    return 0;
}