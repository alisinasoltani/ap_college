#ifndef _IDK_
    #define _IDK_
    void idkWhatToNameThis(int* pointer, int& reference);
    bool isPointerNull(int* pointer);
#endif